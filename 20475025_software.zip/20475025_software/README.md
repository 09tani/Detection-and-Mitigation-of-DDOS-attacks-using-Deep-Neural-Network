# Below are instructions for accessing and using the models

The project was completed and tested on Google Colabs. 

Using these links you can view the project. 

### Accessing the codes
1) DNN code
https://colab.research.google.com/drive/1GVRKIjVDZcwxI7CZNPI3mL0LNq-iwhTD?usp=sharing

2) Baseline code
https://colab.research.google.com/drive/1IXy6ZSGihftdKOnRW2nj_qPA1zkQvjZe?usp=sharing

3) Data Analysis Code
https://colab.research.google.com/drive/1hP3Uk-3roPhX_C--BiW6oGgNIg8yve38?usp=sharing

4) Data Colletion Code
https://colab.research.google.com/drive/1pN03c5iFQNB6ace2Y_HwnD2_AjHijeDi?usp=sharing

### Dataset
The dataset used to train and test the models have been included in the supplementary folder. 
To use the dataset, download them and route the files accordingly to your local setup.  

### Running the models
- For users running on their personal devices root acess needs to be granted to run the Data collection system.  Libary for keras and scapy would also need to be done using pip install. 

- The trained models are ready for used in the supplementary folder. 


For further assitance I can be contacted at: psyit2@nottingham.ac.uk