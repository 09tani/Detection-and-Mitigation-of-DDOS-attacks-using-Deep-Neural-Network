import time
import threading
import pandas as pd
from scapy.all import sniff, IP, TCP
import os

# Flow dictionary
flows = {}
count = 0
#thread lock
flows_lock = threading.Lock()
# TIme out after 60 seconds 
FLOW_TIMEOUT = 60

# Packet storage
captured_packets = []

feature_columns = [
    'Unnamed: 0', 'Src Port', 'Dst Port', 'Protocol', 'Flow Duration',
       'Fwd Header Len', 'Bwd Header Len', 'Init Fwd Win Byts',
       'Init Bwd Win Byts', 'Fwd Act Data Pkts', 'Label'
]

# Process incoming packets, extract flow features, and store them.
def process_packet(packet):
    # A counter for IDing the network packets 
    global count
    if packet.haslayer(IP) and packet.haslayer(TCP):
        ip_layer = packet[IP]
        tcp_layer = packet[TCP]
        key = (ip_layer.src, ip_layer.dst, tcp_layer.sport, tcp_layer.dport, 'TCP')

        # Request lock
        with flows_lock:
            if key not in flows:
                count += 1
                flows[key] = {
                    'Unnamed: 0': count,
                    'Src Port': tcp_layer.sport,
                    'Dst Port': tcp_layer.dport,
                    'Protocol': '0',
                    'Flow Duration': 0,
                    'start_time': packet.time,
                    'end_time': packet.time,
                    'pkt_count': 0,
                    'fwd_pkt_count': 0,
                    'bwd_pkt_count': 0,
                    'Fwd Header Len': 0,
                    'Bwd Header Len': 0,
                    'Init Fwd Win Byts': tcp_layer.window,
                    'Init Bwd Win Byts': 0,
                    'Fwd Act Data Pkts': 0,
                    'flowiat': [],
                    'Label': 'unknown',
                    'initiator': ip_layer.src
                }

            flow = flows[key]
            #last seen
            flow['end_time'] = packet.time
            flow['pkt_count'] += 1

            # Compute arrival Time
            if len(flow['flowiat']) > 0:
                flow['flowiat'].append(packet.time - flow['flowiat'][-1])
            else:
                flow['flowiat'].append(0)  # First packet

            # Determine packet direction: forward if from initiator; else backward.
            if ip_layer.src == flow['initiator']:
                flow['fwd_pkt_count'] += 1
                fwd_hdr_len = tcp_layer.dataofs * 4
                flow['Fwd Header Len'] += fwd_hdr_len

                if len(tcp_layer.payload) > 0:
                    flow['Fwd Act Data Pkts'] += 1
            else:
                flow['bwd_pkt_count'] += 1
                bwd_hdr_len = tcp_layer.dataofs * 4
                flow['Bwd Header Len'] += bwd_hdr_len

                #Set the "Init Bwd Win Byts" when a reverse packet is received
                if flow['Init Bwd Win Byts'] == 0:
                    flow['Init Bwd Win Byts'] = tcp_layer.window

        # Save packet to CSV
        captured_packets.append(packet)

def compute_flow_metrics(flow):
    # print("A new flow is detected.")
    duration = flow['end_time'] - flow['start_time']
    # This is to avoid division by zero !!!
    duration = max(duration, 1)  

    return {
        'Unnamed: 0': flow['Unnamed: 0'],
        'Src Port': flow['Src Port'],
        'Dst Port': flow['Dst Port'],
        'Protocol': flow['Protocol'],
        'Flow Duration': duration,
        'Fwd Header Len': flow['Fwd Header Len'],
        'Bwd Header Len': flow['Bwd Header Len'],
        'Init Fwd Win Byts': flow['Init Fwd Win Byts'],
        'Init Bwd Win Byts': flow['Init Bwd Win Byts'],
        'Fwd Act Data Pkts': flow['Fwd Act Data Pkts'],
        'Label': flow['Label']
    }

def flush_expired_flows():
    csv_file = "network_flows.csv"

    # Check if file exists and write header
    file_exists = os.path.exists(csv_file)
    if not file_exists:
        pd.DataFrame(columns=feature_columns).to_csv(csv_file, index=False)

    while True:
        current_time = time.time()
        expired_keys = []
        flow_metrics = []

        with flows_lock:
            # Find expired flows
            for key, flow in list(flows.items()):
                if current_time - flow['end_time'] > FLOW_TIMEOUT:
                    expired_keys.append(key)

            # Extract metrics for expired flows
            for key in expired_keys:
                flow = flows.pop(key)
                metrics = compute_flow_metrics(flow)
                flow_metrics.append(metrics)

        # Append new flows to CSV
        if flow_metrics:
            df = pd.DataFrame(flow_metrics, columns=feature_columns)
            df.to_csv(csv_file, mode='a', header=False, index=False)
            print(f"Saved {len(flow_metrics)} flows to {csv_file}")

        time.sleep(10)

def start_packet_sniffing():
    print("Start sniffing packets.")
    sniff(prn=process_packet, store=False)


#If the script is run directly, start the sniffing process
# and run the flush and save functions in background threads.
# This allows the script to run indefinitely and process packets in real-time.
if __name__ == '__main__':
    # Start the flush and save functions in background threads
    threading.Thread(target=flush_expired_flows, daemon=True).start()
    print("Starting packet capture...")
    start_packet_sniffing()
    print("Packet capture stopped.")
